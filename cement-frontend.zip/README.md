Calendar, Clock, FileCheck, Award -> Icons will be One from the following
