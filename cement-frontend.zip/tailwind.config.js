export default {
  content: ["./src/**/*.{html,js,ts,jsx,tsx}"], // Adjust paths as needed
  theme: {
    extend: {},
  },
  plugins: [],
};
