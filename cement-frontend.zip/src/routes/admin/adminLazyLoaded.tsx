import { lazy } from "react";

export const SignIn = lazy(() => import("@/pages/Admin/SignIn"));
