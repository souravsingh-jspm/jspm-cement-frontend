export interface ConferanceThemeAdminCreateRequest {
  id: string;
  ct_title: string;
  ct_short_description: string;
}
