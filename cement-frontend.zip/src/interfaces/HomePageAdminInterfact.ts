export interface HomePageAdminCreateRequest {
  id: string;
  home_page_title: string;
  about_jspm_group: string;
  about_jspm_university_pune: string;
  about_soces: string;
}
