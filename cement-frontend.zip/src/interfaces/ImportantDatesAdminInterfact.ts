export interface ImportantDateAdminCreateRequest {
  id: string;
  id_title: string;
  id_date: string;
  id_description: string;
}
