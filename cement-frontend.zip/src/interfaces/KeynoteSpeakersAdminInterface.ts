export interface KeyNoteSpeakerAdminCreateRequest {
  kns_image: string;
  kns_name: string;
  kns_designatin: string;
  id: string;
}
