export interface ConferanceCommitteeCreateRequest {
  id: string;
  cc_role: string;
  cc_image: string;
  cc_name: string;
  cc_designation: string;
}
