export interface ConferanceThemeCreateRequest {
  id: string;
  ct_title: string;
  ct_short_description: string;
}
